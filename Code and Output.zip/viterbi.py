import json
from math import log
from math import inf

def viterbi(fasta, config):
    f=open(config)

    x=f.readline()
    intronlength = float(x.rstrip('\n'))
    x=f.readline()
    exonlength = float(x.rstrip('\n'))
    x=f.readline()
    x=x.rstrip('\n')
    y=json.loads(x)
    intronemission = y
    x=f.readline()
    x=x.rstrip('\n')
    y=json.loads(x)
    exonemssion = y

    #print(intronlength)
    #print(exonlength)
    #print(intronemission)
    #print(exonemssion)


    pi = {'I': 1, 'start': 0, 'middle': 0, 'stop': 0}
    transition = [[((intronlength)-1)/(intronlength), 1/intronlength, 0, 0], [0, 0, 1, 0], [0, 0, ((exonlength/3)-1)/(exonlength/3), 1/(exonlength/3)], [1, 0, 0, 0]]
    #transition = [[0.9, 0.1, 0, 0], [0, 0, 1, 0], [0, 0, 0.9, 0.1], [1, 0, 0, 0]]
    #print(transition)
    #print(transition)
    Estart = exonemssion.copy()
    Emiddle = exonemssion.copy()
    Estop = exonemssion.copy()
    for key in Estart:
        if key == 'ATG' or key == "GTG" or key == "TTG":
            Estart[key] = 1
        else:
            Estart[key] = 0
    for key in Emiddle:
        if key == 'TAG' or key == 'TAA' or key == 'TGA':
            Emiddle[key] = 0
    for key in Estop:
        if key == 'TAG' or key == 'TAA' or key == 'TGA':
            Estop[key] = 1/3
        else:
            Estop[key] = 0
    #print("Estart:")
    #print(Estart)
    #print("Emiddle:")
    #print(Emiddle)
    #print("Estop:")
    #print(Estop)
    #Emissions: intronemission, Estart, Emiddle, Estop
    #transition
    #pi
    dict = {}

    f = open(fasta)
    all_lines=f.readlines()

    for line in all_lines:
        newline = line.rstrip("\n")
        if line[0] == ">":
            s = line.split()
            name = s[0]
            name1 = name.replace(">", "")
            dict[name1] = ''
        else:
            last = list(dict.keys())[-1]
            dict[last] += newline
    #print(dict)
    f.close()
    finaldict = {}

    for key in dict:
        name = key
        states = ['I', 'start', 'middle', 'stop']
        seq = dict[key]
        M = [[None for x in range(len(seq))] for y in range(len(states))]
        pointer = [[None for x in range(len(seq))] for y in range(len(states))]
        for s in range(len(states)):
            if states[s] == 'I':
                M[s][0] = log(pi[states[s]]) + log(intronemission[seq[0]])
                M[s][1] = M[s][0] + log(transition[0][0]) + log(intronemission[seq[1]])
                pointer[s][1] = states[s]
                M[s][2] = M[s][1] + log(transition[0][0]) + log(intronemission[seq[2]])
                pointer[s][2] = states[s]
                #print(M[s][0], M[s][1], M[s][2])
            if states[s] == 'start':
                if Estart[seq[0:3]] != 0:
                #M[s][2] = pi[states[s]] * Estart[seq[0:3]]
                    M[s][2] = log(Estart[seq[0:3]])
                #print(M[s][2])
                else:
                    M[s][2] = -inf
            #print(Emiddle[seq[0:3]])
            if states[s] == 'middle':
                if Emiddle[seq[0:3]] != 0:
                #M[s][2] = pi[states[s]] * Emiddle[seq[0:3]]
                    M[s][2] = log(Emiddle[seq[0:3]])
                    #print(M[s][2])
                else: 
                    M[s][2] = -inf
            if states[s] == 'stop':
                if Estop[seq[0:3]]!=0:
                    #M[s][2] = pi[states[s]] * Estop[seq[0:3]]
                    M[s][2] = log(Estop[seq[0:3]])
                    #print(M[s][2])
                else:
                    M[s][2] = -inf
        #print("initialization complete")
        tempforstart = [0,3]
        for i in range(3, len(seq)):
            for s in range(len(states)):
                if states[s] == 'I':
                    largestx = -inf
                    xstate = ''
                    for k in tempforstart:
                        if transition[k][s]>0 and intronemission[seq[i]]>0:
                            x = M[k][i-1] + log(transition[k][s]) + log(intronemission[seq[i]])
                        else:
                            x = -inf
                        if x >= largestx:
                            largestx = x
                            xstate = states[k]
                    M[s][i] = largestx
                    pointer[s][i] = xstate
                elif states[s] == 'start':
                    largestx = -inf
                    xstate = ''
                    for k in tempforstart:
                        if M[k][i-3] != None:
                            if transition[k][s]>0 and Estart[seq[i-2:i+1]]>0:
                                x = M[k][i-3] + log(transition[k][s]) + log(Estart[seq[i-2:i+1]])
                            else:
                                x = -inf
                            if x >= largestx:
                                largestx = x
                                xstate = states[k]
                    M[s][i] = largestx
                    pointer[s][i] = xstate
                elif states[s] == 'middle':
                    largestx = -inf
                    xstate = ''
                    for k in range(1,3):
                        if M[k][i-3] != None:
                            if transition[k][s]>0 and Emiddle[seq[i-2:i+1]]>0:
                                x = M[k][i-3] + log(transition[k][s]) + log(Emiddle[seq[i-2:i+1]])
                            else:
                                x = -inf
                            if x >= largestx:
                                largestx = x
                                xstate = states[k]
                    M[s][i] = largestx
                    pointer[s][i] = xstate
                elif states[s] == 'stop':
                    largestx = -inf
                    xstate = ''
                    for k in range(2,4):
                        if M[k][i-3] != None:
                            if transition[k][s]>0 and Estop[seq[i-2:i+1]]>0:
                                x = M[k][i-3] + log(transition[k][s]) + log(Estop[seq[i-2:i+1]])
                            else:
                                x = -inf
                            if x >= largestx:
                                largestx = x
                                xstate = states[k]
                    M[s][i] = largestx
                    pointer[s][i] = xstate
                    
        #print("matrix complete")
        
        
        #print(pointer)
        
        path = []
        largestx = -inf
        xstate = ''
        for k in range(len(states)):
            if M[k][len(seq)-1] >= largestx:
                largestx = M[k][len(seq)-1]
                xstate = states[k]
        #print(largestx)
        i = len(seq)-1
        prev = xstate
        #print("hello")
        #print(xstate)
        #print("hello")
        #print('starting traceback')
        while i>-1:
            #print(prev)
            if prev == 'I':
                path.append(prev)
                prev = pointer[0][i]
                i-=1
                #print(path)
                #print(prev)
            
            elif prev == 'start':
                path.append('G')
                path.append('G')
                path.append('G')
                prev = pointer[1][i]
                i-=3
            elif prev == 'middle':
                path.append('G')
                path.append('G')
                path.append('G')
                prev = pointer[2][i]
                i-=3
            elif prev == 'stop':
                path.append('G')
                path.append('G')
                path.append('G')
                prev = pointer[3][i]
                i-=3
            elif prev == None:
                path.append('I')
                prev = pointer[0][i]
                i-=1             
        path.reverse()
        #print(path)

        num = []
        for i in range(len(path)):
            if (i+1) < len(path):
                if path[i] == 'G' and path[i-1] == 'I' or (i==0 and path[i] == 'G'):
                    num.append(i+1)
                elif path[i] == 'G' and path[i+1] == 'I' or (i==(len(path)-1) and path[i] == 'G'):
                    num.append(i+1)

        #print(num)
        finaldict[name] = num
        #print(M[3][len(seq)-22])
        #print(pointer[3][len(seq)-22])
        #print(M[0][len(seq)-22])
    #print(finaldict)
    import gffutils

    fout = open("values.gff3", "w")
    
    for key in finaldict:
            i=0
            num = finaldict[key]
            while i < (len(num))-1:
                start1 = num[i]
                end1 = num[i+1]
                line = gffutils.Feature(seqid=key, source='ens', featuretype='CDS', start=start1, end=end1, strand='+', frame='0', extra='.')
                fout.write(str(line) + '\n')  
                i+=2  
        
    
            
if __name__=="__main__":
    viterbi("seq", "configuration.txt")




