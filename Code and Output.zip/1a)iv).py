
dict = {}

seq = open("1c")
all_lines=seq.readlines()

for line in all_lines:
    newline = line.rstrip("\n")
    if line[0] == ">":
        s = line.split()
        name = s[0]
        name1 = name.replace(">", "")
        dict[name1] = ''
    else:
        last = list(dict.keys())[-1]
        dict[last] += newline
#print(dict)
seq.close()

f = open("1d")
lines=f.readlines()
dict1={}
for line in lines:
    x = line.split()
    if x[0] in dict1:
        for i in range(len(x)):
            if (x[i] == "CDS" and x[i+4] == "+"):
                dict1[x[0]].append(x[i+1])
                dict1[x[0]].append(x[i+2])
                break
    else:
        if len(x) > 5:
            if x[1] == "European":
                dict1[x[0]] = []
#print(dict1)
f.close()
start = []
end = []
temp = 0
d = {}
count =0
for key in dict:
    for key1 in dict1:
        if key==key1:
            positions = dict1[key1]
            seq = dict[key]
            i=0
            while i < (len(positions)):
                position = int(positions[i])
                endp = int(positions[i+1])
                y = seq[position-1] + seq[position] + seq[position+1]
                z = seq[endp-3] + seq[endp-2] + seq[endp-1]
                if y in start:
                    temp +=1
                else:
                    start.append(y)
                if z in end:
                    temp += 1
                else:
                    end.append(z)
                while position < (int(positions[i+1])-1):
                    x = seq[position-1] + seq[position] + seq[position+1]
                    if x in d:
                        d[x]+=1
                        count+=1
                    else:
                        d[x] = 1
                        count+=1
                    position += 3
                i+=2
#print(d)
#print(count)

total = 0
for key in d:
    total+=d[key]
for key in d:
    x = d[key]/total
    d[key] = round(x,4)

print(d)
print(start)
print(end)