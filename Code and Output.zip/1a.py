from io import StringIO
from Bio import SeqIO
#import itertools
#import pandas as pd
#import gffpandas.gffpandas as gffpd
import pprint
from BCBio.GFF import GFFExaminer
from BCBio import GFF
import gffutils

#in_file = "annotated"
#examiner = GFFExaminer()
#in_handle = open(in_file)
#pprint.pprint(examiner.parent_child_map(in_handle))
#filter = in_file.filter_feature_of_type(['CDS'])
#print(filter.df)
#limit_info = dict(gff_type=["CDS"])
#for rec in GFF.parse(in_handle, limit_info=limit_info):
    #print(rec)
#in_handle.close()
#db = gffutils.example_filename('annotated')
#print(open(db).read())
f = open("annotated")
lines=f.readlines()
count=0
l=[]
lengths=[]
for line in lines:
    count += 1
    x = line.split()
    if (count>1 and count<153):
        lengths.append(x[3])
        print(x[3])
    for i in range(len(x)):
        if (x[i] == "CDS" and x[i+4] == "+"):
            l.append(x[i+1])
            l.append(x[i+2])
            break

#print(l)
#print(lengths)

f.close()
exonlist=[]
i=0
while i<(len(l)):
    exonlength = int(l[i+1]) - int(l[i])
    exonlist.append(exonlength)
    i += 2
avg_exon = 0
num_exon = 0
total_exon = 0
for i in range(len(exonlist)):
    total_exon += exonlist[i]
    num_exon += 1
avg_exon = total_exon/num_exon
print(avg_exon)

avg_intron = 0
num_intron = 0
total_intron = 0
intronlist = []
intronpositions = []
i=2
while i<(len(l)):
    if int(l[i]) > int(l[i-1]):
        #print(l[i])
        #print(l[i-1])
        intronlength = int(l[i]) - int(l[i-1])
        intronlist.append(intronlength)
        intronpositions.append(int(l[i-1]))
        intronpositions.append(int(l[i]))
    i += 2
#print(intronlist)
for i in range(len(intronlist)):
    total_intron += intronlist[i]
    num_intron += 1
avg_intron = total_intron/num_intron
print(avg_intron)
#print(intronpositions)

seq = open("seq")
all_lines=seq.readlines()
seqlist = []
for line in all_lines:
    line.split()
    if line[0] == ">":
        continue
    for i in range(len(line)):
        if line[i] != '\n':
            seqlist.append(line[i])
    #print(seqlist)
    #break
#print(seqlist)
seq.close()
x = 0
#intronpositions
#lengths
j=0
i=0
A = 0
C = 0
G = 0
T = 0
while i<(len(seqlist)):
    i+=1
    #print(x)
    if (x!=0 and x<len(intronpositions) and intronpositions[x] < intronpositions[x-1]):
        #print(len(seqlist))
        del seqlist[:int(lengths[j])]
        del intronpositions[:x]
        x=0
        j+=1
        i=0
        continue
    if(x<len(intronpositions)):
        #print(len(seqlist))
        #print(i)
            
        if ((i+1) > (intronpositions[x]) and (i+1) < intronpositions[x+1]):
            #print(i+1)
            #print(seqlist[i])
            if (seqlist[i] == 'A'):
                A+=1
            elif (seqlist[i] == 'C'):
                C+=1
            elif (seqlist[i] == 'G'):
                G+=1
            elif (seqlist[i] == 'T'):
                T+=1
        elif ((i+1) == intronpositions[x+1]):
            x+=2

Total = A + C + G + T
A = A/Total
C = C/Total
G = G/Total
T = T/Total
print(A)
print(C)
print(G)
print(T)
#print(seqlist)




