f = open("1d")
lines=f.readlines()
dict1={}
annotatedgenes = 0
for line in lines:
    x = line.split()
    if x[0] in dict1:
        for i in range(len(x)):
            if (x[i] == "CDS" and x[i+4] == "+"):
                dict1[x[0]].append(x[i+1])
                dict1[x[0]].append(x[i+2])
                annotatedgenes +=1
                break
    else:
        if len(x) > 5:
            if x[1] == "European":
                dict1[x[0]] = []
#print(dict1)
f.close()

dict = {}

f1 = open('values1.gff3')
all_lines=f1.readlines()
predictedgenes = 0
for line in all_lines:
    s = line.split()
    name = s[0]
    if name in dict:
        dict[name].append(s[3])
        dict[name].append(s[4])
        predictedgenes += 1
    else:
        dict[name] = [s[3], s[4]]
        predictedgenes += 1
#print(dict)
    
f1.close()

print(annotatedgenes)
print(predictedgenes)

#dict1 = {'a': ['1', '2', '3', '4'], 'b': ['1','2']}
#dict = {'a': ['1', '2'], 'b': ['1','2', '3', '4', '5', '6']}

#annotatedgenes = 3
#predictedgenes = 4

matched = 0
start =0
end =0

for key1 in dict1:
    for key in dict:
        if key1 == key:
            annotated = dict1[key1]
            predicted = dict[key]
            i=0
            j=0
            while i < (len(annotated)-1):
                while j < (len(predicted)-1):
                    #print("_________________________")
                    #print(annotated[i], annotated[i+1])
                    #print(predicted[j], predicted[j+1])
                    #print("_________________________")
                    if annotated[i] == predicted[j] and annotated[i+1] == predicted[j+1]:
                        #print(annotated[i], annotated[i+1])
                        #print(predicted[j], predicted[j+1])
                        matched+=1
                    if annotated[i] == predicted[j] and annotated[i+1] !=  predicted[j+1]:
                        start +=1
                    if annotated[i+1] == predicted[j+1] and annotated[i] != predicted[j]:
                        end+=1
                    j+=2
                i+=2
                j=0
            #print(key, matched, len(annotated))

print(matched)
print(start)
print(end)

frac1 = matched/annotatedgenes
frac2 = start/annotatedgenes
frac3 = end/annotatedgenes
frac4 = 1 - matched/annotatedgenes

frac11 = matched/predictedgenes
frac22 = start/predictedgenes
frac33 = end/predictedgenes
frac44 = 1 - matched/predictedgenes

print(frac1)
print(frac2)
print(frac3)
print(frac4)


print(frac11)
print(frac22)
print(frac33)
print(frac44)